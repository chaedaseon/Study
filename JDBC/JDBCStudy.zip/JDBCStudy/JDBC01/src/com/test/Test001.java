/*===================
 	Test001.java
===================*/

package com.test;

public class Test001
{
	public static void main(String[] args)
	{
		System.out.println("JAVA Test");
	}
}
